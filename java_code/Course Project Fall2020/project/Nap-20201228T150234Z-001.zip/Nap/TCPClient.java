/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */
import java.net.*;
import java.io.*;

public class TCPClient {
 public static final int SERVICE_PORT = 3810;
 public static void main(String args[]) {

  try {

   Socket client = new Socket("127.0.0.1", SERVICE_PORT);
   client.setSoTimeout(2000);

   BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
   System.out.println("Enter your choice number:");
   System.out.println("Menu :-");
   System.out.println("1.. Student info by name");
   System.out.println("2. Student info by ID.");
   System.out.println("3. Add student.");
   System.out.println("4. Save and quit. ");
   String response = reader.readLine();
   int choice = Integer.parseInt(response);
   OutputStream out = client.getOutputStream();
   PrintStream pout = new PrintStream(out);
   BufferedReader read = new BufferedReader(new InputStreamReader(client.getInputStream()));

   switch (choice) {
    case 1:

     pout.println("1");
     System.out.println("Enter student name:");
     String name = reader.readLine();
     pout.println(name);


     System.out.println("Student name:  " + read.readLine());
     System.out.println("Student ID: " + read.read());
     System.out.println("Student GPA: " + Double.parseDouble(read.readLine()));
     // Close the connection
     client.close();


     break;



    case 2:

     pout.println("2");
     int ID = Integer.parseInt(read.readLine());
     pout.println(ID);

     System.out.println("Student name:  " + read.readLine());
     System.out.println("Student ID: " + read.read());
     System.out.println("Student GPA: " + Double.parseDouble(read.readLine()));
     // Close the connection
     client.close();


     break;


    case 3:

     pout.println("3");
     System.out.println("Enter student name:");
     String Name = reader.readLine();
     //pout.println(Name);
     System.out.println("Enter student ID:");
     int Id = reader.read();
     // pout.println(Id);

     System.out.println("Enter student GPA:");



     BufferedReader readergpa = new BufferedReader(new InputStreamReader(System.in));

     double GPA = Double.parseDouble(readergpa.readLine());

     //pout.println(GPA);


     client.close();



    case 4:
     pout.println("4");
     client.close();
     break;

   }

  } catch (IOException ioe) {
   System.err.println("Error " + ioe);
  }
 }
}