/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Manal Abulainain
 */

import java.io.*;
import java.net.BindException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

public class TCPServer {
 public static final int SERVICE_PORT = 3810;
 public static String fileName = "log.txt";
 public static void main(String args[]) {
  try {
   Vector StudentInfo;
   try {
    FileInputStream fin = new FileInputStream("studinfo.out");
    // Connect an object input stream to the list
    ObjectInputStream oin = new ObjectInputStream(fin);
    try {
     // Read the vector back from the list
     Object obj = oin.readObject();
     // Cast back to a vector
     StudentInfo = (Vector) obj;
    } catch (ClassCastException cce) {
     // Can't read it, create a blank one
     StudentInfo = new Vector();
    } catch (ClassNotFoundException cnfe) {
     // Can't read it, create a blank one
     StudentInfo = new Vector();
    }
    fin.close();
   } catch (FileNotFoundException fnfe) {
    // Create a blank vector
    StudentInfo = new Vector();
   }
   try {
    ServerSocket server = new ServerSocket(SERVICE_PORT, 20);

    InetAddress ip = InetAddress.getLocalHost();
    // Loop indefinitely, accepting clients
    for (;;) {



     // Get the next TCP client

     try {


      Socket nextClient = server.accept();
      nextClient.setSoTimeout(60000);
      InputStream in = nextClient.getInputStream();
      // Display connection details
      try {
       BufferedReader reader = new BufferedReader(new InputStreamReader(nextClient.getInputStream()));
       nextClient.setSoTimeout(2000);



       BufferedReader Din = new BufferedReader(new InputStreamReader(nextClient.getInputStream()));
       PrintWriter Dout = new PrintWriter(new FileWriter(fileName));
       Dout.println(new java.util.Date());
       Dout.println("Port : " + nextClient.getPort());
       Dout.println(ip.getHostAddress());
       Din.close();
       Dout.close();

       String s = reader.readLine();

       int choice = Integer.parseInt(s);
       OutputStream out = nextClient.getOutputStream();
       PrintStream pout = new PrintStream(out);
       FileInputStream fin = new FileInputStream("studinfo.out");
       ObjectInputStream oin = new ObjectInputStream(fin);
       FileOutputStream fout = new FileOutputStream("studinfo.out");
       ObjectOutputStream oout = new ObjectOutputStream(fout);
       switch (choice) {
        case 1:

         String RecivedName = reader.readLine();
         Student s1;
         try {




          for (Enumeration e = StudentInfo.elements(); e.hasMoreElements();) {

           s1 = (Student) e.nextElement();
           if (s1.getName().equals(RecivedName)) {
            pout.print(s1.getName());
            pout.print(s1.getID());
            pout.print(s1.getGPA());


           };


          }


          out.flush();

          out.close();
         } catch (ClassCastException cce) {
          System.out.println("Most likely there is no student saved");
         }

         fin.close();
         break;
         // }
         //catch (FileNotFoundException fnfe){
         //     System.out.println("Could not find file");
         //  }
        case 2:
         int RecivedID = Integer.parseInt(reader.readLine());
         Student s2;



         for (Enumeration e = StudentInfo.elements(); e.hasMoreElements();) {

          s2 = (Student) e.nextElement();
          if (s2.getID() == RecivedID) {
           pout.print(s2.getName());
           pout.print(s2.getID());
           pout.print(s2.getGPA());


          };


         }

         fin.close();

         break;
        case 3:

         String RecivedName3 = reader.readLine();

         int RecivedID4 = Integer.parseInt(reader.readLine());

         double RecivedGPA5 = Double.parseDouble(reader.readLine());
         Student stu = new Student(RecivedName3, RecivedID4, RecivedGPA5);

         StudentInfo.add(stu);
         fout.close();
         break;
        case 4:

         FileOutputStream foutt = new FileOutputStream("studinfo.out");
         // Construct an object output stream
         ObjectOutputStream ooutt = new ObjectOutputStream(foutt);
         // Write the object to the stream
         ooutt.writeObject(StudentInfo);
         foutt.close();
         System.exit(0);
         break;
       }
      } catch (IOException ex) {

       System.out.println("Bad client, BYE!!");
      }
     } catch (IOException ioe) {
      System.out.println("Bored of waiting, no client!!");
     }
    }
   } catch (BindException be) {
    System.err.println("Service already running on port " + SERVICE_PORT);
   } catch (IOException ioe) {
    System.err.println(ioe);
   }

  } catch (IOException ioe) {
   System.err.println("I/O error");
  }
 }
}